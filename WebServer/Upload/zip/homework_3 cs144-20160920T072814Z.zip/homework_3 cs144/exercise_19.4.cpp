
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdlib>

using namespace std;

struct StudentInfo {
	std::string name;
	int grade;
};

vector<StudentInfo>::iterator p;

void printStrudentInfor(vector<StudentInfo> container);
void sortStrudentInfo(vector<StudentInfo> &container);
bool sorting(const StudentInfo container1, const StudentInfo container2);
int maxGrade(vector<StudentInfo> container);
int minGrade(vector<StudentInfo> container);
bool compareMin(const StudentInfo container1, const StudentInfo container2);
bool compareMax(const StudentInfo container1, const StudentInfo container2);
int average(vector<StudentInfo> container);

int main()
{

	StudentInfo st1, st2, st3, st4, st5, st6, st7, st8, st9, st10;

	vector<StudentInfo> container;


	st1.name = "konal";
	st1.grade = 76;

	st2.name = "veli";
	st2.grade = 60;

	st3.name = "john";
	st3.grade = 90;

	st4.name = "cali";
	st4.grade = 98;

	st5.name = "mike";
	st5.grade = 70;

	st6.name = "rohan";
	st6.grade = 87;

	st7.name = "keli";
	st7.grade = 69;

	st8.name = "cimara";
	st8.grade = 99;

	st9.name = "sipi";
	st9.grade = 56;

	st10.name = "mikal";
	st10.grade = 81;

	container.push_back(st1);
	container.push_back(st2);
	container.push_back(st3);
	container.push_back(st4);
	container.push_back(st5);
	container.push_back(st6);
	container.push_back(st7);
	container.push_back(st8);
	container.push_back(st9);
	container.push_back(st10);

	cout << endl << " Before  sorting ............... " << endl;
	printStrudentInfor(container);

	cout << endl << " After sorting ................. " << endl;
	sortStrudentInfo(container);

	printStrudentInfor(container);

	cout << endl << "Summary of class .................." << endl;
	cout << endl << "max grade in class :" << maxGrade(container) << endl;
	cout << "min grade in class :" << minGrade(container) << endl;
	cout << "avg grade of class :" << average(container) << endl;


	return 0;
}

void printStrudentInfor(vector<StudentInfo> container) {
	int count = 1;
	for (p = container.begin(); p != container.end(); p++) {
		cout << endl << count << ". Student name : " << p->name << ", " << " grade : " << p->grade << endl;
		count++;
	}
}

void sortStrudentInfo(vector<StudentInfo> &container) {

	sort( container.begin(), container.end(), sorting);

}

bool sorting( const StudentInfo container1, const StudentInfo container2) {
	// return container1.name.compare(container2.name);
	// cout << container1.name << " < " << container2.name << " = "  << endl;
	return container1.name[0] < container2.name[0];
}

int maxGrade(vector<StudentInfo> container) {
	//  max_element(container.begin(), container.end(), compareMax);

	return max_element(container.begin(), container.end(), compareMax)->grade;

}

int minGrade(vector<StudentInfo> container) {
	return min_element(container.begin(), container.end(), compareMax)->grade;
}

int average(vector<StudentInfo> container) {

	int avg = 0;

	for (p = container.begin(); p != container.end(); p++) {
		avg = avg + p->grade;
	}

	return avg / container.size();

}

bool compareMax(const StudentInfo container1, const StudentInfo container2) {
	return container1.grade < container2.grade;
}

bool compareMin(const StudentInfo container1, const StudentInfo container2) {
	return container1.grade > container2.grade;
}

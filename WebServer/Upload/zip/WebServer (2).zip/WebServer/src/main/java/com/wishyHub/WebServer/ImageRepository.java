/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.wishyHub.WebServer;

import com.wishyHub.WebServer.entities.Upload;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Maninderpal
 */
public interface ImageRepository extends JpaRepository<Upload,Integer>{
    
}

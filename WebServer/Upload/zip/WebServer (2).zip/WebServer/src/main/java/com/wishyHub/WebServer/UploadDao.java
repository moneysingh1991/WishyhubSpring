/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.wishyHub.WebServer;

import com.wishyHub.WebServer.entities.Upload;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Maninderpal
 */

@Repository
public class UploadDao {
    @Autowired
    
    private SessionFactory sessionFactory;
    
    public void CreateUploadFile(Upload upload) {
        Session session= null;
        
        try {
                session = sessionFactory.openSession();
                
                session.beginTransaction();
                Integer id = (Integer) session.save(upload);
                System.out.println("Upload file created with id: " + id);
                session.getTransaction().commit();
        } catch(Exception e) {
                e.printStackTrace();
        }
    }
}

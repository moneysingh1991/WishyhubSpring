/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.wishyHub.WebServer.util;

import javax.persistence.EntityManagerFactory;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 *
 * @author Maninderpal
 */

//@Configuration
public class HibernateUtilConfig {
    
//    @Autowired
//    
//    private EntityManagerFactory entityManagerFactory;
//    
//    @Bean
//    public SessionFactory getSessionFactory()  {
//        
//        if(entityManagerFactory.unwrap(SessionFactory.class) == null) {
//          
//        }
//        return entityManagerFactory.unwrap(SessionFactory.class);
//    }
    
}

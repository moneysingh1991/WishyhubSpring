/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.wishyHub.WebServer;

import com.wishyHub.WebServer.entities.Upload;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Maninderpal
 */

@RestController
@RequestMapping("/rest/image")
public class GetController {
    
    ImageRepository imageRepo;
    @GetMapping("/all")
    public List<Upload> getAll() {
        return imageRepo.findAll();
    }
}

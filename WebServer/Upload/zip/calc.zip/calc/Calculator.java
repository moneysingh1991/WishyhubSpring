
public class Calculator {
	
	public Double square(Double x) { return x * x; }
	
	public Double cube(Double x) { return x * x * x; }
	
	// = n * (n - 1) * ... * 1
	public Integer fact(Integer n) {
		Integer result = 1;
		for(int i = 1; i <= n; i++) result *= i;
		return result;
	}
	
	// = n + (n - 1) + ... + 1
	public Integer tri(Integer n) {
		return (n <= 0)? 0: n + tri(n - 1);
	}
	
	// = true if n has no divisors
	public Boolean isPrime(Integer n) {
		Boolean result = true;
		for(int i = 1; i < n/2; i++) {
			result = (n % i != 0);
			if (!result) break;
		}
		return result;
	}

}

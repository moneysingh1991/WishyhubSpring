
import bt.*;

public class CalculatorTest {

	public static void main(String[] args) {
		
		Calculator calc = new Calculator();
		
		// make unit tests for square and cube:
		UnitTest<Double, Double> squareTest = new UnitTest<Double, Double>("square", calc::square);
		UnitTest<Double, Double> cubeTest = new UnitTest<Double, Double>("cube", calc::cube);
		squareTest.put(3.0,  9.0);
		squareTest.put(4.0,  16.0);
		squareTest.put(5.0,  25.0);
		squareTest.put(6.0,  36.0);
		
		cubeTest.put(3.0,  27.0);
		cubeTest.put(4.0,  64.0);
		cubeTest.put(5.0,  125.0);
		cubeTest.put(6.0,  216.0);
		
		// add unit tests to a test suite:
		TestSuite calcTests1 = new TestSuite();
		calcTests1.add(squareTest);
		calcTests1.add(cubeTest);
		
		// make unit tests for fact and tri:
		UnitTest<Integer, Integer> factTest = new UnitTest<Integer, Integer>("fact", calc::fact);
		UnitTest<Integer, Integer> triTest = new UnitTest<Integer, Integer>("tri", calc::tri);
		factTest.put(3,  6);
		factTest.put(4,  24);
		factTest.put(5,  120);
		factTest.put(1,  1);
		factTest.put(0, 1);
		
		triTest.put(3,  6);
		triTest.put(4,  10);
		triTest.put(5,  15);
		triTest.put(0,  0);
		
		// add unit tests to a test suite:
		TestSuite calcTests2 = new TestSuite();
		calcTests2.add(factTest);
		calcTests2.add(triTest);
		
		// make unit tests for fact and tri:
		UnitTest<Integer, Boolean> primeTest = new UnitTest<Integer, Boolean>("isPrime", calc::isPrime);
		primeTest.put(2, true);
		primeTest.put(5, true);
		primeTest.put(9, false);
		primeTest.put(1, false);
		
		// make system test:
		TestSuite systemTest = new TestSuite();
		systemTest.add(calcTests1);
		systemTest.add(calcTests2);
		systemTest.add(primeTest);
		
		// run system test:
		int numErrors = systemTest.run();
		System.out.println("Total #errors = " + numErrors);
		
	}

}

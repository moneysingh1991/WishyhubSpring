Drivers: LG United Mobile Mac Driver
Version: 4.5	
UNINSTALL:

If this driver causes problems, or if you would like to Uninstall, reboot the machine with no USB devices plugged in

 1. Run uninstall provided with the package

Then, reboot again...


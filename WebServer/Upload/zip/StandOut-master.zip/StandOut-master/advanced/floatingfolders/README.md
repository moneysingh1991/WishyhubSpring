Floating-Folders
================
![Floating Folders](https://dl.dropbox.com/u/30367/hosted/floating%20folders.png)
### Coming Soon
Meanwhile, checkout the demo video at http://www.youtube.com/watch?v=S3vHjxonOeg

Join the conversation at http://forum.xda-developers.com/showthread.php?t=1688531

![StandOut](https://dl.dropbox.com/u/30367/hosted/StandOut.png)

### Support or Contact
Feel free to send messages or questions to markwei@gmail.com.